# 🚀 دليل نشر تطبيق مكناس الإمبراطورية على Google Play Store
## Ahmed Khettari — khettarihistory@gmail.com

---

## 📦 محتويات هذا المجلد

```
meknes-app/
├── index.html          ← الموقع الكامل (PWA-ready)
├── manifest.json       ← هوية التطبيق
├── sw.js               ← Service Worker (وضع أوفلاين)
├── icons/
│   ├── icon-72.png
│   ├── icon-96.png
│   ├── icon-128.png
│   ├── icon-144.png
│   ├── icon-152.png
│   ├── icon-192.png
│   ├── icon-384.png
│   ├── icon-512.png    ← الأيقونة الرئيسية
│   └── screenshot1.png ← صورة للمتجر
└── GUIDE.md            ← هذا الدليل
```

---

## 🗺️ خريطة الطريق الكاملة

```
STEP 1: GitHub (استضافة مجانية)
    ↓
STEP 2: PWABuilder (تحويل إلى APK)
    ↓
STEP 3: Google Play Console (نشر)
    ↓
STEP 4: 🎉 تطبيقك على Play Store
```

---

## ✅ STEP 1 — استضافة الموقع على GitHub Pages (مجاناً)

### 1.1 إنشاء حساب GitHub
1. افتح: **https://github.com**
2. اضغط **Sign up**
3. أدخل بريدك: `khettarihistory@gmail.com`
4. اختر اسم مستخدم: مثل `ahmed-khettari`

### 1.2 إنشاء Repository جديد
1. اضغط **New repository** (الزر الأخضر)
2. اسم المشروع: `meknes-imperial`
3. اختر **Public**
4. اضغط **Create repository**

### 1.3 رفع الملفات
1. اضغط **uploading an existing file**
2. ارفع هذه الملفات:
   - `index.html`
   - `manifest.json`
   - `sw.js`
   - مجلد `icons/` كاملاً
3. اضغط **Commit changes**

### 1.4 تفعيل GitHub Pages
1. اذهب لـ **Settings** → **Pages**
2. في **Branch** اختر `main`
3. اضغط **Save**
4. بعد دقيقة، موقعك سيكون على:
   ```
   https://ahmed-khettari.github.io/meknes-imperial/
   ```
   **📌 احتفظ بهذا الرابط — ستحتاجه في الخطوة التالية**

---

## ✅ STEP 2 — تحويل الموقع إلى APK بـ PWABuilder

### 2.1 فتح PWABuilder
1. افتح: **https://www.pwabuilder.com**
2. في خانة البحث، أدخل رابط موقعك:
   ```
   https://ahmed-khettari.github.io/meknes-imperial/
   ```
3. اضغط **Start**

### 2.2 تحقق من النتيجة
- ستظهر نقاط تقييم PWA — تأكد أن النتيجة **جيدة أو ممتازة**
- إذا كانت النتيجة منخفضة، تأكد من رفع جميع الملفات

### 2.3 توليد حزمة Android
1. اضغط **Package for stores**
2. اختر **Google Play**
3. اضغط **Generate Package**
4. ستنزل ملف `.zip` يحتوي:
   - `app-release-bundle.aab` ← ملف التطبيق الرئيسي
   - `signing.keystore` ← مفتاح التوقيع (احتفظ به بأمان!)
   - `signing-key-info.txt` ← بيانات المفتاح

### ⚠️ مهم جداً:
```
احفظ ملف signing.keystore في مكان آمن!
إذا فقدته لن تستطيع تحديث تطبيقك أبداً.
```

---

## ✅ STEP 3 — نشر التطبيق على Google Play Console

### 3.1 إنشاء حساب المطوّر (25$ مرة واحدة)
1. افتح: **https://play.google.com/console**
2. سجّل دخول بحساب Google الخاص بك
3. ادفع رسوم التسجيل: **25 دولار** (Visa/PayPal)
4. أكمل معلومات حسابك

### 3.2 إنشاء تطبيق جديد
1. اضغط **Create app**
2. أدخل المعلومات:
   - **App name:** مكناس الإمبراطورية | Imperial Meknes
   - **Default language:** Arabic
   - **App or game:** App
   - **Free or paid:** Free
3. اضغط **Create app**

### 3.3 إعداد صفحة التطبيق (Store Listing)

#### 📝 الوصف القصير (80 حرف):
```
دليل سياحي شامل لمعالم مكناس الإمبراطورية — Guide touristique de Meknès
```

#### 📝 الوصف الكامل (4000 حرف):
```
🏰 مكناس الإمبراطورية — دليلك السياحي الذكي

اكتشف روائع مدينة مكناس الإمبراطورية، إحدى أعرق المدن التاريخية في المغرب
والمدرجة على قائمة التراث العالمي لليونسكو.

✨ ما يقدمه هذا التطبيق:
• 8 معالم تاريخية مع أوصاف تفصيلية كاملة
• خرائط تفاعلية مباشرة لكل معلمة
• يعمل بـ 3 لغات: العربية، الفرنسية، الإنجليزية
• نصائح عملية للزوار (أوقات الفتح، الأسعار، التنقل)
• يعمل بدون إنترنت (وضع أوفلاين)

🏛️ المعالم المشمولة:
1. باب المنصور لعلج — أعظم أبواب المغرب
2. ضريح مولاي إسماعيل — مزار ملكي مفتوح للجميع
3. ساحة الهديم — قلب المدينة النابض
4. متحف دار الجامعي — قصر أندلسي فريد
5. هري السواني وبحيرة أكدال — مخازن ملكية أسطورية
6. وليلي الرومانية — موقع أثري يونسكو
7. باب الخميس — بوابة القرن السابع عشر
8. مولاي إدريس زرهون — المدينة المقدسة

تصميم: Ahmed Khettari | khettarihistory@gmail.com
```

### 3.4 رفع الصور المطلوبة
Go to **Store listing** → **Graphics**:

| الصورة | الحجم | المصدر |
|--------|-------|--------|
| App Icon | 512×512 px | `icons/icon-512.png` |
| Feature Graphic | 1024×500 px | صمّمها على Canva |
| Phone Screenshots | 1080×1920 px | `icons/screenshot1.png` |

**💡 نصيحة:** استخدم **https://www.canva.com** لتصميم Feature Graphic بسرعة.

### 3.5 إعدادات التطبيق

#### Content Rating (تصنيف المحتوى):
1. اذهب لـ **Policy** → **App content**
2. أجب على أسئلة تصنيف المحتوى
3. التصنيف المتوقع: **Everyone (للجميع)**

#### Target Audience:
- الفئة العمرية: **18+** أو **All ages**

#### Category:
- **Travel & Local**

### 3.6 رفع ملف AAB
1. اذهب لـ **Release** → **Production**
2. اضغط **Create new release**
3. ارفع ملف `app-release-bundle.aab`
4. في **Release notes** اكتب:
   ```
   الإصدار الأول — First release
   دليل سياحي لمعالم مكناس الإمبراطورية
   ```
5. اضغط **Save** ثم **Review release**

### 3.7 إرسال للمراجعة
1. راجع كل القسم الأحمر وأكمله
2. اضغط **Start rollout to Production**
3. انتظر المراجعة: **من 2 إلى 7 أيام**
4. ستصلك رسالة على بريدك عند القبول ✅

---

## 🔄 تحديث التطبيق مستقبلاً

عند تعديل الموقع:
1. حدّث ملف `index.html` على GitHub
2. في `manifest.json` غيّر رقم الإصدار
3. ارفع APK جديد على Play Console
4. رقم الإصدار يجب أن يكون **أكبر من السابق دائماً**

---

## 📊 معلومات التطبيق للمرجع

| البيان | القيمة |
|--------|--------|
| اسم التطبيق | مكناس الإمبراطورية |
| Package Name | com.khettari.meknes.imperial |
| Version | 1.0.0 |
| Min Android | 5.0 (API 21) |
| الفئة | Travel & Local |
| السعر | مجاني |
| المطوّر | Ahmed Khettari |
| البريد | khettarihistory@gmail.com |

---

## 🆘 مشاكل شائعة وحلولها

| المشكلة | الحل |
|---------|------|
| PWABuilder يرفض الموقع | تأكد من رفع manifest.json وsw.js |
| Play Console يرفض AAB | تحقق من صحة ملف التوقيع |
| الأيقونة لا تظهر | الحجم يجب أن يكون 512×512 بالضبط |
| التطبيق يُرفض | راجع سياسة Google Play وصحح الوصف |

---

## 📞 للمساعدة

- **GitHub Docs:** https://docs.github.com/pages
- **PWABuilder Docs:** https://docs.pwabuilder.com
- **Play Console Help:** https://support.google.com/googleplay/android-developer

---

*أعدّه لك Claude AI بناءً على طلب Ahmed Khettari*
*khettarihistory@gmail.com | مكناس 2025*
